"use strict";
const jwtSecret = process.env.JWT_SECRET;