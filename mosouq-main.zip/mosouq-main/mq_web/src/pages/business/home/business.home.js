import React from "react";

const BusinessHome =()=>{
    return(
        <div>
            <img src="/businesshome.jpeg" style={{width:'100%'}} />
        </div>
    )
}

export default BusinessHome