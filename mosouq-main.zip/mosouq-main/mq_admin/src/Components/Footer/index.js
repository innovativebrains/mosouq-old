import React from "react";
import "./index.css"

const Footer =()=>{
    return(
        <div className="footer">   
             Copyright © 2024 - 2034 Innovative Brains, Inc. All Rights Reserved
        </div>
    ) 
}

export default Footer